require("Category") || stop("unable to load Category")
BiocGenerics:::testPackage("Category", "UnitTests", ".*_test\\.R$")
