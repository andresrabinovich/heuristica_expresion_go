setGeneric("goDag", function(r) standardGeneric("goDag"))

